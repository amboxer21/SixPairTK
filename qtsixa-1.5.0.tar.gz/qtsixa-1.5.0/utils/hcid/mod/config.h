#define CONFIGDIR "/var/lib/sixad/config"
#define SERVICEDIR "/var/lib/sixad/services"
#define STORAGEDIR "/var/lib/sixad"
#define HCI_SECMGR 0
#define VERSION "1.5.0"
